README

This messages uses a codeset member DIE for OperationQualifier, which is wating approval by IATA