README - normal flight sequence

normal.1482.1		-	flight starting position
normal.1482.1.departed	-	flight departed
normal.1482.1.airborne	-	flight airborne
normal.1482.1.touchdown	-	flight landed
normal.1482.1.arrival	-	flight arrived