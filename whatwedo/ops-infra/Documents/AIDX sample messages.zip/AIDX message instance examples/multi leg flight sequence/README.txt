README - Multi leg flight sequence

multi.8277.1.1		-	starting position first leg
multi.8277.1.arrival	-	first leg arrives
multi.8277.2.departed	-	second leg departed
multi.8277.2.airborne	-	second leg airborne
multi.8277.2.touchdown	-	second leg touchdown
multi.8277.2.arrival	-	second leg arrival




