README - Ground return sequence

1394.1				-	starting position
1394.departed			-	flight departs
1394.ground_return		-	flight declares ground return
1394.second_attempt_etd		-	next attempt estimates
1394.second_attempt_departed	-	next attempt departs
