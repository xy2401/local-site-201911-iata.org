README - Pre departure diversion sequence (re-route)

107.pre_dep_divert.1 					- 	starting position
107.pre_dep_divert.different_destination		-	flight re-routed
107.pre_dep_divert.continuation				-	continue to original destination

115.pre_dep_divert.no_continue.1			-	re-route without continuation starting position
115.pre_dep_divert.no_continue.different_destination	-	re-route without continuation re-routed