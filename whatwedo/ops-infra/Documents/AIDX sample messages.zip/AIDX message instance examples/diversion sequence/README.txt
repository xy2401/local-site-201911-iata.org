README - Diversion Sequence (airborne)

175.divert.1				-	starting position
175.divert.airborne			-	flight airborne
175.divert.different_destination	-	flight diverts
175.divert.continuation			-	flight continues to original destination