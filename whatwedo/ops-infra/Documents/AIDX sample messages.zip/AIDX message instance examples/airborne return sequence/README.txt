REAME - Airborne return sequence

766.airborne_return.1				-	starting position
766.airborne_return.departed			-	flight departs
766.airborne_return.airborne			-	flight takes off
766.airborne_return.return_leg			-	flight declares returns to departure station
766.airborne_return.return_leg.touchdown	-	returning leg touches down
766.airborne_return.return_leg.arrived		-	returning leg arrives
766.airborne_return.return_leg.continue_leg.1	-	next departure attempt rewarn status
766.airborne_return.return_leg.continue_leg.1	-	next departure attempt estimating